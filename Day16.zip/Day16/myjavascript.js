function stringLength() {
    // Retrieving the values of form elements
    var name = $("#firstName").val();
    alert("User name is :" + name.length);
    }